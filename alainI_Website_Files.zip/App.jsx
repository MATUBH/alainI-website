import React from "react";

export default function AlAinIWebsite() {
  return (
    <div className="bg-[#F9F4EF] text-[#0D1C2E] font-sans">
      {/* Header */}
      <header className="flex justify-between items-center p-6 shadow">
        <h1 className="text-2xl font-bold">alainI</h1>
        <nav className="space-x-4">
          <a href="#services" className="hover:text-[#6A1B9A]">Services</a>
          <a href="#reports" className="hover:text-[#6A1B9A]">Reports</a>
          <a href="#about" className="hover:text-[#6A1B9A]">About</a>
          <a href="#contact" className="hover:text-[#6A1B9A]">Contact</a>
        </nav>
      </header>

      {/* Hero Section */}
      <section className="text-center py-20">
        <h2 className="text-4xl font-bold mb-4">Media Intelligence for a Smarter Tomorrow</h2>
        <p className="text-lg mb-6">Monitoring. Analysis. Insight. Action.</p>
        <button className="bg-[#6A1B9A] text-white px-6 py-2 rounded-xl">Request a Demo</button>
      </section>

      {/* About Section */}
      <section id="about" className="px-10 py-12">
        <h3 className="text-3xl font-semibold mb-4">Built in Al Ain, Designed for the Gulf</h3>
        <p>
          alainI is a UAE-based media intelligence and analytics agency that blends AI tools with human
          insight to empower government and enterprise communication teams.
        </p>
        <ul className="list-disc list-inside mt-4 space-y-1">
          <li>UAE-based servers</li>
          <li>Multilingual monitoring</li>
          <li>Crisis support</li>
          <li>Real-time alerts</li>
        </ul>
      </section>

      {/* Services */}
      <section id="services" className="bg-white px-10 py-12">
        <h3 className="text-3xl font-semibold mb-6">Our Services</h3>
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {[
            "Media & Social Listening",
            "Sentiment Analysis",
            "Campaign Impact Tracking",
            "Influencer & Stakeholder Analysis",
            "Crisis Detection & Alerts",
            "Custom Dashboards & Reports"
          ].map((service, idx) => (
            <div key={idx} className="p-4 border border-[#6A1B9A] rounded-xl shadow-sm">
              <p className="font-medium text-lg">{service}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Packages */}
      <section className="px-10 py-12" id="reports">
        <h3 className="text-3xl font-semibold mb-6">Service Packages</h3>
        <div className="grid md:grid-cols-3 gap-6">
          {[
            { name: "Starter", price: "AED 3,000–5,000", desc: "Basic weekly insights" },
            { name: "Standard", price: "AED 7,500–10,000", desc: "Monthly PDF + sentiment" },
            { name: "Advanced", price: "AED 15,000–25,000", desc: "Real-time alerts, dashboards" }
          ].map((pkg, idx) => (
            <div key={idx} className="bg-[#6A1B9A] text-white p-6 rounded-xl">
              <h4 className="text-xl font-bold mb-2">{pkg.name}</h4>
              <p className="mb-1">{pkg.price}</p>
              <p className="text-sm mb-4">{pkg.desc}</p>
              <button className="bg-white text-[#6A1B9A] px-4 py-1 rounded-xl">Get Started</button>
            </div>
          ))}
        </div>
      </section>

      {/* Contact */}
      <section id="contact" className="px-10 py-12 bg-white">
        <h3 className="text-3xl font-semibold mb-4">Let’s Work Together</h3>
        <p>Email: hello@alaini.ae</p>
        <p>Website: www.alaini.ae</p>
        <p>Location: Al Ain, United Arab Emirates</p>
      </section>

      {/* Footer */}
      <footer className="bg-[#F9F4EF] text-center py-4 text-sm text-[#6A1B9A]">
        © 2025 alainI – Al Ain Intelligence. All rights reserved.
      </footer>
    </div>
  );
}
